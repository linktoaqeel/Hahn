﻿using Hahn.ApplicatonProcess.December2020.Data.DAL;
using Hahn.ApplicatonProcess.December2020.Data.IRepositories;
using Hahn.ApplicatonProcess.December2020.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Data
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly HahnDBContext _context;

        private ApplicantRepository _ApplicantRepository;

        public IApplicantRepository Applicant => _ApplicantRepository = _ApplicantRepository ?? new ApplicantRepository(_context);


        public UnitOfWork(HahnDBContext context)
        {
            this._context = context;
        }

        public async Task<int> CommitAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public int Commit()
        {
            return _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Dispose();
        }

    }
}
