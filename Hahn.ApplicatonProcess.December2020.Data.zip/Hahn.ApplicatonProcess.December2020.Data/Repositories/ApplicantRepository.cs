﻿using Hahn.ApplicatonProcess.December2020.Data.DAL;
using Hahn.ApplicatonProcess.December2020.Data.IRepositories;
using Hahn.ApplicatonProcess.December2020.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Data.Repositories
{
    public class ApplicantRepository : BaseRepository<Applicant>, IApplicantRepository
    {
        public ApplicantRepository(HahnDBContext context) : base(context)
        {

        }
    }
}
