﻿using FluentValidation;
using Hahn.ApplicatonProcess.December2020.Data.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Data.ModelValidators
{
    public class ApplicantValidator : AbstractValidator<Applicant>
    {
        public ApplicantValidator()
        {
            RuleFor(x => x.Name).MinimumLength(5);
            RuleFor(x => x.FamilyName).MinimumLength(5);
            RuleFor(x => x.Address).MinimumLength(10);
            RuleFor(x => x.CountryOfOrigin).Must(ValidCountryName).WithMessage("Please specify the valid country of origin");
            RuleFor(x => x.EMailAddress).EmailAddress(FluentValidation.Validators.EmailValidationMode.AspNetCoreCompatible);
            RuleFor(x => x.Age).ExclusiveBetween(20, 60);
        }

        public bool ValidCountryName(string name)
        {
            bool chk = false;
            string ApiUriForCountryName = "https://restcountries.eu/rest/v2/name/" + name + "?fullText=true&fields=name;";
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ApiUriForCountryName);
                request.Method = "GET";
                request.ContentType = "application/json";

                WebResponse webResponse = request.GetResponse();
                using (Stream webStream = webResponse.GetResponseStream() ?? Stream.Null)
                using (StreamReader responseReader = new StreamReader(webStream))
                {
                    string response = (responseReader.ReadToEnd() + "").Trim().ToLower();

                    if (response.Contains("name") && response.Contains(name.ToLower()))
                        chk = true;
                }
            }
            catch (Exception ex)
            {

            }

            return chk;
        }
    }
}
