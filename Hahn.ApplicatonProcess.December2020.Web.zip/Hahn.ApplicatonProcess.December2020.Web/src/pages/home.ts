import { bindable, View, inject, NewInstance } from 'aurelia-framework';
import { Router, RoutableComponentActivate, RoutableComponentDeactivate, RouterConfiguration } from 'aurelia-router';

import { I18N } from 'aurelia-i18n';
import { ValidationRules, ValidationController, validationMessages } from 'aurelia-validation';

import { HttpClient } from 'aurelia-fetch-client';

@inject(Router, NewInstance.of(ValidationController), I18N)

export class Home {
    //firstName;
    //familyName; 
    static inject = [I18N];
    applicant: { firstName, familyName };

    router: Router;
    controller;
    i18n;

    message = '';

    enableSubmit: boolean = false;

    constructor(router, controller, i18n) {
        this.router = router;
        this.controller = controller;
        this.i18n = i18n;

        this.applicant = {
            firstName: "",
            familyName: ""
        }

        validationMessages['required'] = "\${$displayName}  cann't left empty.";
        ValidationRules
            .ensure('firstName').displayName("First Name").required().minLength(5)
            .ensure('familyName').displayName("Family Name").required().minLength(5)
            .on(this.applicant);


        this.controller.validate();
        console.log(this.i18n.getLocale());
        console.log(this.i18n.tr('firstName'));
        this.i18n.setLocale('de').then(() => {
            console.log(this.i18n.getLocale());
            console.log(this.i18n.tr('firstName'));
        });
    }

    applicantChanged(newValue, oldValue) {
        this.executeValidation();
    }

    submit() {
        this.executeValidation();
    }

    switchLanguage() {
        const currentLocale = this.i18n.getLocale();
        console.log("current language");
        console.log(this.i18n.getLocale());
        this.i18n.setLocale(currentLocale === 'en' ? 'de' : 'en')
            .then(() => this.executeValidation());
    }

    executeValidation() {
        this.controller.validate()
            .then(errors => {
                if (errors.length === 0) {
                    this.message = "All Good";//this.i18n.tr('allGood'); 
                    //this.enableSubmit = true;
                } else {
                    this.message = "You have Errors";//this.i18n.tr('youHaveErrors'); 
                    //this.enableSubmit = false;
                }
            });
        console.log(this.message);
        console.log(this.controller.errors.length);
    }



    created(owningView: View, myView: View) {
        console.log({ event: 'created: Home', owningView: owningView, myView: myView });
    }

    bind(bindingContext: Object, overrideContext: Object) {
        console.log({ event: 'bind: Home', bindingContext: bindingContext, overrideContext: overrideContext });

        this.controller.validate();

        console.log("bind method called");
        console.log(this.i18n.getLocale());
        console.log(this.i18n.tr('firstName'));
    }

    attached() {
        console.log({ event: 'attached: Home', this: this });


    }

    detached() {
        console.log({ event: 'detached: Home', this: this });
    }

    unbind() {
        console.log({ event: 'unbind: Home', this: this });
    }

    canActivate() {
        return true;
    }

    activate() {
    }

    canDeactivate() {
        return true;
    }

    deactivate() {

    }

}
