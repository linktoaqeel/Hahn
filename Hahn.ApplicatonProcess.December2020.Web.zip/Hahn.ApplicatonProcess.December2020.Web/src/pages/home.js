var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { inject, NewInstance } from 'aurelia-framework';
import { Router } from 'aurelia-router';
import { I18N } from 'aurelia-i18n';
import { ValidationRules, ValidationController, validationMessages } from 'aurelia-validation';
var Home = (function () {
    function Home(router, controller, i18n) {
        var _this = this;
        this.message = '';
        this.enableSubmit = false;
        this.router = router;
        this.controller = controller;
        this.i18n = i18n;
        this.applicant = {
            firstName: "",
            familyName: ""
        };
        validationMessages['required'] = "\${$displayName}  cann't left empty.";
        ValidationRules
            .ensure('firstName').displayName("First Name").required().minLength(5)
            .ensure('familyName').displayName("Family Name").required().minLength(5)
            .on(this.applicant);
        this.controller.validate();
        console.log(this.i18n.getLocale());
        console.log(this.i18n.tr('firstName'));
        this.i18n.setLocale('de').then(function () {
            console.log(_this.i18n.getLocale());
            console.log(_this.i18n.tr('firstName'));
        });
    }
    Home.prototype.applicantChanged = function (newValue, oldValue) {
        this.executeValidation();
    };
    Home.prototype.submit = function () {
        this.executeValidation();
    };
    Home.prototype.switchLanguage = function () {
        var _this = this;
        var currentLocale = this.i18n.getLocale();
        console.log("current language");
        console.log(this.i18n.getLocale());
        this.i18n.setLocale(currentLocale === 'en' ? 'de' : 'en')
            .then(function () { return _this.executeValidation(); });
    };
    Home.prototype.executeValidation = function () {
        var _this = this;
        this.controller.validate()
            .then(function (errors) {
            if (errors.length === 0) {
                _this.message = "All Good";
            }
            else {
                _this.message = "You have Errors";
            }
        });
        console.log(this.message);
        console.log(this.controller.errors.length);
    };
    Home.prototype.created = function (owningView, myView) {
        console.log({ event: 'created: Home', owningView: owningView, myView: myView });
    };
    Home.prototype.bind = function (bindingContext, overrideContext) {
        console.log({ event: 'bind: Home', bindingContext: bindingContext, overrideContext: overrideContext });
        this.controller.validate();
        console.log("bind method called");
        console.log(this.i18n.getLocale());
        console.log(this.i18n.tr('firstName'));
    };
    Home.prototype.attached = function () {
        console.log({ event: 'attached: Home', this: this });
    };
    Home.prototype.detached = function () {
        console.log({ event: 'detached: Home', this: this });
    };
    Home.prototype.unbind = function () {
        console.log({ event: 'unbind: Home', this: this });
    };
    Home.prototype.canActivate = function () {
        return true;
    };
    Home.prototype.activate = function () {
    };
    Home.prototype.canDeactivate = function () {
        return true;
    };
    Home.prototype.deactivate = function () {
    };
    Home.inject = [I18N];
    Home = __decorate([
        inject(Router, NewInstance.of(ValidationController), I18N),
        __metadata("design:paramtypes", [Object, Object, Object])
    ], Home);
    return Home;
}());
export { Home };
//# sourceMappingURL=home.js.map