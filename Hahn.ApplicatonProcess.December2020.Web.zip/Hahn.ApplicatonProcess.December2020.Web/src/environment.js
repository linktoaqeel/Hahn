export default {
    debug: true,
    testing: true
};
//# sourceMappingURL=environment.js.map