var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import './styles.css';
import { bindable, BindingEngine, inject } from 'aurelia-framework';
var NavRendererCustomElement = (function () {
    function NavRendererCustomElement(bindingEngine) {
        this.bindingEngine = bindingEngine;
        this.level = 1;
        this.navItems = [];
    }
    NavRendererCustomElement.prototype.bind = function (bindingContext, overrideContext) {
        var _this = this;
        var toBeProcessed = this.router.navigation.sort(function (a, b) {
            return a.relativeHref.length - b.relativeHref.length;
        });
        this.processNavItems(toBeProcessed);
        this.navItems = this.navItems
            .filter(function (i) { return i.info != null; })
            .filter(function (i) { return (i.info.relativeHref.split("/").length - 1) < (_this.level + 1); });
    };
    NavRendererCustomElement.prototype.processNavItems = function (items) {
        var _this = this;
        var _loop_1 = function () {
            parts = items[a].href.split("/").filter(function (i) { return i != ""; });
            var cp = "";
            var pp = "";
            var ci = 0;
            if (parts.length == 0) {
                item = this_1.getRouterItemByPath("");
                this_1.addNavItem(item, null, "/");
            }
            parts.forEach(function (p) {
                var primary, parent, primaryItem, parentItem;
                ci++;
                cp = cp + (cp == "" ? "" : "/") + p;
                primary = cp;
                parent = pp;
                if (parent != "")
                    parentItem = _this.getRouterItemByPath(parent);
                primaryItem = _this.getRouterItemByPath(primary);
                if (primaryItem != null)
                    _this.addNavItem(primaryItem, parentItem, primaryItem.relativeHref);
                pp = cp;
            });
        };
        var this_1 = this, parts, item;
        for (var a = 0; a < items.length; a++) {
            _loop_1();
        }
        this.orderNavItems();
    };
    NavRendererCustomElement.prototype.orderNavItems = function () {
        this.navItems = this.navItems.sort(function (a, b) {
            return a.info.order - b.info.order;
        });
    };
    NavRendererCustomElement.prototype.getRouterItemByPath = function (path) {
        return this.router.navigation.filter(function (r) { return r.href == "/" + path; })[0];
    };
    NavRendererCustomElement.prototype.getNavItemByPath = function (path) {
        return this.navItems.filter(function (n) { return n.info.relativeHref == path; })[0];
    };
    NavRendererCustomElement.prototype.addNavItem = function (item, parent, url) {
        var i = this.getNavItemByPath(url);
        if (i != null)
            return;
        i = new NavItem(item, parent, url);
        if (parent != null) {
            var ni = this.getNavItemByPath(parent.relativeHref);
            i.level = ni.level + 1;
            ni.childItems.push(i);
        }
        else
            i.level = 0;
        this.navItems.push(i);
    };
    __decorate([
        bindable,
        __metadata("design:type", Object)
    ], NavRendererCustomElement.prototype, "router", void 0);
    __decorate([
        bindable,
        __metadata("design:type", Object)
    ], NavRendererCustomElement.prototype, "level", void 0);
    __decorate([
        bindable,
        __metadata("design:type", Array)
    ], NavRendererCustomElement.prototype, "navItems", void 0);
    NavRendererCustomElement = __decorate([
        inject(BindingEngine),
        __metadata("design:paramtypes", [Object])
    ], NavRendererCustomElement);
    return NavRendererCustomElement;
}());
export { NavRendererCustomElement };
var NavItem = (function () {
    function NavItem(item, parent, url) {
        this.info = item;
        this.parentItem = parent;
        this.relativeUrl = url;
        this.childItems = new Array();
    }
    Object.defineProperty(NavItem.prototype, "hasParent", {
        get: function () { return this.parentItem != null; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NavItem.prototype, "hasChildren", {
        get: function () { return this.childItems.length > 0; },
        enumerable: false,
        configurable: true
    });
    return NavItem;
}());
export { NavItem };
//# sourceMappingURL=nav-renderer.js.map