import { bindable } from 'aurelia-framework';

export class NavRendererItemCustomElement
{
  @bindable item;

  constructor() {

  }

}

