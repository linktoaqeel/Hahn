import './styles.css'
import { bindable, BindingEngine, inject } from 'aurelia-framework';

@inject(BindingEngine)
export class NavRendererCustomElement
{
  @bindable router:any;
  @bindable level = 1;
  @bindable navItems:any[] = [];

  constructor(private bindingEngine) {
  }

  bind(bindingContext: Object, overrideContext: Object) {
    var toBeProcessed = this.router.navigation.sort(function (a, b) {
      return a.relativeHref.length - b.relativeHref.length;
    });

    this.processNavItems(toBeProcessed);

    // filter for specified level (root = 1)
    this.navItems = this.navItems
      .filter((i) => { return i.info != null })
      .filter((i) => { return (i.info.relativeHref.split("/").length - 1) < (this.level + 1) });
  }

  processNavItems(items) {
    for (var a = 0; a < items.length; a++) {
      var parts = items[a].href.split("/").filter(function (i) { return i != "" });

      let cp: string = "";
      let pp: string = "";
      let ci: number = 0;

      if (parts.length == 0) {
        var item = this.getRouterItemByPath("");
        this.addNavItem(item, null, "/");
      }

      parts.forEach((p) => {
        var primary, parent, primaryItem, parentItem;
        ci++;

        cp = cp + (cp==""?"":"/") + p;
        primary = cp;
        parent = pp;

        if (parent != "")
          parentItem = this.getRouterItemByPath(parent);

        primaryItem = this.getRouterItemByPath(primary);
        if (primaryItem != null)
          this.addNavItem(primaryItem, parentItem, primaryItem.relativeHref);

        pp = cp;
      });
    }

    this.orderNavItems();
  }

  orderNavItems() {
    this.navItems = this.navItems.sort(function (a, b) {
      return a.info.order - b.info.order;
    });
  }

  getRouterItemByPath(path: string) {
    return this.router.navigation.filter((r) => { return r.href == "/" + path })[0];
  }

  getNavItemByPath(path: string): NavItem {
    return this.navItems.filter((n) => { return n.info.relativeHref == path })[0];
  }

  addNavItem(item: any, parent: any, url: string) {
    var i = this.getNavItemByPath(url);

    if (i != null)
      return;

    i = new NavItem(item, parent, url);

    if (parent != null) {
      var ni = this.getNavItemByPath(parent.relativeHref);
      i.level = ni.level + 1;
      ni.childItems.push(i);
    }
    else
      i.level = 0;

    this.navItems.push(i);
  }

}

export class NavItem {
  public parentItem: NavItem;
  public childItems: NavItem[];
  public info: NavItem;
  public relativeUrl: string;
  public level: number;

  public get hasParent(): boolean { return this.parentItem != null; }
  public get hasChildren(): boolean { return this.childItems.length > 0; }

  constructor(item, parent, url) {
    this.info = item;
    this.parentItem = parent;
    this.relativeUrl = url;
    this.childItems = new Array<NavItem>();
  }
}
