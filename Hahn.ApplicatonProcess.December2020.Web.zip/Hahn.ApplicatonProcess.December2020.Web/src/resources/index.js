import { PLATFORM } from 'aurelia-framework';
export function configure(config) {
    config.globalResources([
        PLATFORM.moduleName('./elements/nav-renderer-item'),
        PLATFORM.moduleName('./elements/nav-renderer')
    ]);
}
//# sourceMappingURL=index.js.map