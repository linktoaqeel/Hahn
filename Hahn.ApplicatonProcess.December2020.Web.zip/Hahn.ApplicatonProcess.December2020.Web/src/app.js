var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
import { inject, NewInstance } from 'aurelia-framework';
import { Router } from 'aurelia-router';
import { I18N } from 'aurelia-i18n';
import { ValidationRules, ValidationController, validationMessages } from 'aurelia-validation';
import { HttpClient, json } from 'aurelia-fetch-client';
import { DialogService } from 'aurelia-dialog';
var App = (function () {
    function App(router, controller, i18n, http, dialogService) {
        var _this = this;
        this.httpClient = new HttpClient();
        this.message = '';
        this.switchLanguageLabel = '';
        this.router = router;
        this.controller = controller;
        this.i18n = i18n;
        this.dialogService = dialogService;
        http.configure(function (config) {
            config;
            config.withInterceptor({
                request: function (message) {
                    return message;
                },
                requestError: function (error) {
                    throw error;
                },
                response: function (message) {
                    return message;
                },
                responseError: function (error) {
                    throw error;
                }
            })
                .withBaseUrl('https://localhost:44396/Api/')
                .withDefaults({
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'Fetch'
                }
            });
        });
        this.http = http;
        this.applicant = {
            Name: "",
            FamilyName: "",
            Address: "",
            CountryOfOrigin: "",
            EMailAddress: "",
            Age: 0,
            Hired: true
        };
        validationMessages['required'] = "\${$displayName}  cann't left empty.";
        ValidationRules
            .ensure('Name').displayName("First Name").required().minLength(5)
            .ensure('FamilyName').displayName("Family Name").required().minLength(5)
            .ensure('Address').displayName("Address").required().minLength(10)
            .ensure('CountryOfOrigin').displayName("CountryOfOrigin").required()
            .ensure('EMailAddress').displayName("EMailAddress").required().email()
            .ensure('Age').displayName("Age").required().between(20, 60)
            .on(this.applicant);
        this.controller.validate();
        console.log(this.i18n.getLocale());
        console.log(this.i18n.tr('firstName'));
        this.i18n.setLocale('de').then(function () {
            console.log(_this.i18n.getLocale());
            console.log(_this.i18n.tr('firstName'));
        });
    }
    App.prototype.bind = function (bindingContext, overrideContext) {
        console.log({ event: 'bind: Home', bindingContext: bindingContext, overrideContext: overrideContext });
        this.controller.validate();
        console.log("bind method called");
        console.log(this.i18n.getLocale());
        console.log(this.i18n.tr('firstName'));
        if (this.i18n.getLocale() == "en")
            this.switchLanguageLabel = "German";
        else
            this.switchLanguageLabel = "English";
    };
    App.prototype.submit = function () {
        var _this = this;
        this.executeValidation();
        if (this.controller.errors.length == 0) {
            console.log("submmit button clicked");
            var data = "{firstName=" + this.applicant.Name + ",familyName=" + this.applicant.FamilyName + "}";
            console.log(data);
            this.http.fetch('Applicant', {
                method: 'post',
                body: json(this.applicant)
            })
                .then(function (response) { return __awaiter(_this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!(response.status === 400)) return [3, 2];
                            return [4, response.json()];
                        case 1:
                            data = _a.sent();
                            console.log(data);
                            alert(data);
                            this.dialogService.open({ model: 'Good or Bad?', lock: false }).whenClosed(function (response) {
                                if (!response.wasCancelled) {
                                    console.log('good');
                                }
                                else {
                                    console.log('bad');
                                }
                                console.log(response.output);
                            });
                            return [3, 3];
                        case 2:
                            console.log(response.json());
                            this.reset();
                            alert("Data is successfully posted");
                            _a.label = 3;
                        case 3: return [2];
                    }
                });
            }); })
                .catch(function (error) {
                console.log("error");
                console.log(error);
            });
        }
    };
    App.prototype.reset = function () {
        this.applicant = {
            Name: "",
            FamilyName: "",
            Address: "",
            CountryOfOrigin: "",
            EMailAddress: "",
            Age: 0,
            Hired: false
        };
        console.log("reset form called");
    };
    App.prototype.switchLanguage = function () {
        var _this = this;
        var currentLocale = this.i18n.getLocale();
        console.log("current language");
        console.log(this.i18n.getLocale());
        this.i18n.setLocale(currentLocale === 'en' ? 'de' : 'en')
            .then(function () { return _this.executeValidation(); });
        if (this.i18n.getLocale() == "en")
            this.switchLanguageLabel = "German";
        else
            this.switchLanguageLabel = "English";
    };
    App.prototype.executeValidation = function () {
        var _this = this;
        this.controller.validate()
            .then(function (errors) {
            if (errors.length === 0) {
                _this.message = "All Good";
            }
            else {
                _this.message = "You have Errors";
            }
        });
        console.log(this.message);
        console.log(this.controller.errors.length);
    };
    App.inject = [I18N, DialogService];
    App = __decorate([
        inject(Router, NewInstance.of(ValidationController), I18N, HttpClient),
        __metadata("design:paramtypes", [Object, Object, Object, Object, Object])
    ], App);
    return App;
}());
export { App };
//# sourceMappingURL=app.js.map