﻿using Hahn.ApplicatonProcess.December2020.Data.Models;
using Hahn.ApplicatonProcess.December2020.Data.ModelValidators;
using Hahn.ApplicatonProcess.December2020.Domain.IServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicantController : ControllerBase
    {
        private readonly ILogger<ApplicantController> logger;
        IApplicantService applicantService;

        public ApplicantController(ILogger<ApplicantController> _logger, IApplicantService _applicantService)
        {
            logger = _logger;
            applicantService = _applicantService;
        }

        /// <summary>
        /// Gets the list of applicants
        /// </summary>
        /// <returns>The list of Applicants.</returns>
        [HttpGet]
        public IEnumerable<Applicant> Get()
        {
            string message = "";
            try
            {
                List<Applicant> list = applicantService.GetAll().ToList();
                return list;
            }
            catch (Exception ex)
            {
                message = "There is an error while accessing the records." + ex.Message;
                logger.LogError(ex, ex.Message);
                return null;
            }

        }

        /// <summary>
        /// Gets the applicants object
        /// </summary> 
        /// <param name="id" example="1">The product id</param>
        /// <returns>The Applicant object.</returns>
        // GET api/<ApplicantController>/1
        [HttpGet("{id}", Name = "Get")]
        public IActionResult Get(int id)
        {
            try
            {
                Applicant applicant = applicantService.GetById(id);
                if (applicant != null)
                {
                    return Ok(applicant);
                }
                else
                {
                    logger.LogInformation("Applicant ID " + id + " not found");
                    return NotFound(id);
                }

            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return NotFound(id);
            }
        }

        /// <summary>
        /// Add a new applicant 
        /// </summary> 
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /Applicant
        ///     {
        ///        "name": "Aqeel",
        ///        "familyName": "Baloch",
        ///        "address": "Abu Dhabi City, UAE",
        ///        "countryOfOrigin": "Pakistan",
        ///        "eMailAddress": "linktoaqeel@gmail.com",
        ///        "age": 30,
        ///        "hired": true
        ///     }
        ///
        /// </remarks>
        /// <param name="applicant"></param>
        /// <returns>A newly created applicant</returns>
        /// <response code="201">Returns the newly created object</response>
        /// <response code="400">If the item is null</response>

        // POST api/<ApplicantController>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Produces("application/json")]
        public IActionResult Post([FromBody] Applicant applicant)
        {
            ApplicantValidator validationRules = new ApplicantValidator();
            var results = validationRules.Validate(applicant);
            string message = "";
            if (results.IsValid == false)
            {
                foreach (var err in results.Errors)
                {
                    message += err.ErrorMessage + Environment.NewLine;
                }
                return BadRequest(message);
            }

            try
            {
                Applicant obj = applicantService.Create(applicant);
                return CreatedAtRoute("Get", new { id = obj.ID }, obj);

            }
            catch (Exception ex)
            {
                message = "There is an error while creating a new record.";
                logger.LogError(ex, ex.Message);
                return BadRequest(message);
            }

        }

        /// <summary>
        /// Update the applicant properties
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /Applicant
        ///     {
        ///        "name": "Aqeel",
        ///        "familyName": "Baloch",
        ///        "address": "Abu Dhabi City, UAE",
        ///        "countryOfOrigin": "Pakistan",
        ///        "eMailAddress": "linktoaqeel@gmail.com",
        ///        "age": 30,
        ///        "hired": true
        ///     }
        ///
        /// </remarks>
        /// <param name="id"></param>
        /// <param name="applicant"></param>
        /// <returns>A newly created applicant</returns>
        /// <response code="201">Returns the newly created object</response>
        /// <response code="400">If the item is null</response>

        // POST api/<ApplicantController>

        // PUT api/<ApplicantController>/5
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult Put(int id, [FromBody] Applicant applicant)
        {
            ApplicantValidator validationRules = new ApplicantValidator();
            var results = validationRules.Validate(applicant);
            string message = "";
            int result = 0;
            if (results.IsValid == false)
            {
                foreach (var err in results.Errors)
                {
                    message += err.ErrorMessage + Environment.NewLine;
                }
                return BadRequest(message);
            }

            try
            {
                Applicant existingApplicant = applicantService.GetById(id);
                if (existingApplicant == null)
                {
                    message = "Record doesnot exists for provided Id.";
                    return BadRequest(message);
                }
                result = applicantService.Update(existingApplicant, applicant);

            }
            catch (Exception ex)
            {
                message = "There is an error while updating the record.";
                logger.LogError(ex, ex.Message);
                return BadRequest(message);
            }

            return Ok(result);
        }


        /// <summary>
        /// Delete the applicant object
        /// </summary> 
        /// <param name="id" example="1">The applicant id</param> 
        // DELETE api/<ApplicantController>/1
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            string message = "";
            int result = 0;
            try
            {
                Applicant existingApplicant = applicantService.GetById(id);
                if (existingApplicant == null)
                {
                    message = "Record doesnot exists for provided Id.";
                    return BadRequest(message);
                }
                result = applicantService.Delete(existingApplicant);
            }
            catch (Exception ex)
            {
                message = "There is an error while deleting the record.";
                return BadRequest(message);
            }

            return Ok(result);
        }
    }
}
