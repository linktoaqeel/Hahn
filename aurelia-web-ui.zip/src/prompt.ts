
import { DialogController } from 'aurelia-dialog'; 

export class Prompt {
    static inject = [DialogController];

    controller;
    answer;
    applicant: {Name, FamilyName, Address, CountryOfOrigin, EMailAddress, Age, Hired};
  
  
    constructor(controller){
      this.controller = controller;
      this.answer = null;
  
      this.applicant = {
        Name: "", 
        FamilyName: "", 
        Address: "", 
        CountryOfOrigin: "", 
        EMailAddress: "", 
        Age: 0,
        Hired: true
      } 
      
      controller.settings.lock = false;
      controller.settings.centerHorizontalOnly = true;
    }
  }
  

  