import { bindable, View, inject, NewInstance  } from 'aurelia-framework';
import { Router, RoutableComponentActivate, RoutableComponentDeactivate, RouterConfiguration } from 'aurelia-router';

import { I18N } from 'aurelia-i18n';
import { ValidationRules, ValidationController, validationMessages } from 'aurelia-validation';

import {bootstrap} from 'aurelia-bootstrapper';

import {HttpClient, json, Interceptor } from 'aurelia-fetch-client'; 

import {DialogService} from 'aurelia-dialog'; 
import {Prompt } from 'prompt'; 

require('./bootstrap/dist/css/bootstrap.min.css'); 
require('bootstrap'); 

@inject(Router, NewInstance.of(ValidationController), I18N, HttpClient)

export class App {
  static inject = [I18N, DialogService];

  router: Router;
  controller;
  i18n;
  http;
  dialogService;

  httpClient = new HttpClient();
  
  applicant: {Name, FamilyName, Address, CountryOfOrigin, EMailAddress, Age, Hired};

  public message = '';
  public switchLanguageLabel = '';
  
  constructor(router, controller, i18n, http, dialogService) {
    this.router = router;
    this.controller = controller;
    this.i18n = i18n;
    this.dialogService = dialogService;

    http.configure(config => {
      config
      config.withInterceptor({
        request(message) { 
          return message;
        },  
        requestError(error) { 
          throw error;
        },  
        response(message) { 
          return message;
        },  
        responseError(error) { 
          throw error;
        }
      })
      .withBaseUrl('https://localhost:44396/Api/')
      .withDefaults({ 
        headers: {
          'Accept': 'application/json',
          'X-Requested-With': 'Fetch'
        }
      });
        //.useStandardConfiguration();
    });

    this.http = http;

    this.applicant = {
      Name: "", 
      FamilyName: "", 
      Address: "", 
      CountryOfOrigin: "", 
      EMailAddress: "", 
      Age: 0,
      Hired: true
    } 
    
    validationMessages['required'] = "\${$displayName}  cann't left empty."; 
    ValidationRules
      .ensure('Name').displayName("First Name").required().minLength(5)
      .ensure('FamilyName').displayName("Family Name").required().minLength(5)
      .ensure('Address').displayName("Address").required().minLength(10)
      .ensure('CountryOfOrigin').displayName("CountryOfOrigin").required()
      .ensure('EMailAddress').displayName("EMailAddress").required().email()
      .ensure('Age').displayName("Age").required().between(20, 60)
      .on(this.applicant); 
      
      this.controller.validate(); 
      console.log(this.i18n.getLocale());
      console.log(this.i18n.tr('firstName'));
      this.i18n.setLocale('de').then(() => {
        console.log(this.i18n.getLocale());
        console.log(this.i18n.tr('firstName'));
      }); 
      
  }

  bind(bindingContext: Object, overrideContext: Object) {
      console.log({ event: 'bind: Home', bindingContext: bindingContext, overrideContext: overrideContext });

      this.controller.validate();

      console.log("bind method called");
      console.log(this.i18n.getLocale());
      console.log(this.i18n.tr('firstName'));
      if (this.i18n.getLocale() == "en")
        this.switchLanguageLabel = "German";
      else
        this.switchLanguageLabel = "English";
  }

  submit(){
    this.executeValidation();

    if (this.controller.errors.length == 0){
      console.log("submmit button clicked");

      var data = "{firstName=" + this.applicant.Name + ",familyName=" + this.applicant.FamilyName + "}";

      console.log(data);

      this.http.fetch('Applicant', {
        method: 'post',
        body: json(this.applicant)
     })
     .then(async response => { 
        // do whatever here 
        if (response.status === 400) { 
          var data = await response.json();
          console.log(data);  
          alert(data);
          this.dialogService.open({ model: 'Good or Bad?', lock: false }).whenClosed(response => {
            if (!response.wasCancelled) {
              console.log('good');
            } else {
              console.log('bad');
            }
            console.log(response.output);
          });
        }
        else
        {
          console.log(response.json());
          this.reset();
          alert("Data is successfully posted");
        }
     }) 
     .catch(error => {
      console.log("error");
      console.log(error); 
    });
    }
  }

  reset(){ 
    this.applicant = {
      Name: "", 
      FamilyName: "", 
      Address: "", 
      CountryOfOrigin: "", 
      EMailAddress: "", 
      Age: 0,
      Hired: false
    } 
    
    console.log("reset form called");
  }

  switchLanguage() {
      const currentLocale = this.i18n.getLocale();
      console.log("current language");
      console.log(this.i18n.getLocale());
      this.i18n.setLocale(currentLocale === 'en' ? 'de' : 'en')
          .then(() => this.executeValidation());

      if (this.i18n.getLocale() == "en")
        this.switchLanguageLabel = "German";
      else
        this.switchLanguageLabel = "English";
  }

  executeValidation() {
      this.controller.validate()
          .then(errors => {
              if (errors.length === 0) {
                  this.message = "All Good";//this.i18n.tr('allGood'); 
                  //this.enableSubmit = true;
              } else {
                  this.message = "You have Errors";//this.i18n.tr('youHaveErrors'); 
                  //this.enableSubmit = false;
              }
          });
      console.log(this.message);
      console.log(this.controller.errors.length); 
  }

}
