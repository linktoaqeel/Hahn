﻿using AutoMapper;
using Hahn.ApplicatonProcess.December2020.Data;
using Hahn.ApplicatonProcess.December2020.Data.DAL;
using Hahn.ApplicatonProcess.December2020.Data.Models;
using Hahn.ApplicatonProcess.December2020.Domain.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Services
{

    public class ApplicantService : IApplicantService
    {
        private readonly IUnitOfWork _unitOfWork;
        public ApplicantService(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }


        #region Async CRUD operations 
        public async Task<Applicant> CreateAsync(Applicant newEntity)
        {
            await _unitOfWork.Applicant.AddAsync(newEntity);
            return newEntity;
        }

        public async Task<IEnumerable<Applicant>> CreateRangeAsync(IEnumerable<Applicant> entityList)
        {
            await _unitOfWork.Applicant.AddRangeAsync(entityList);
            return entityList;
        }

        public async Task DeleteAsync(Applicant entity)
        {
            _unitOfWork.Applicant.Remove(entity);
            await _unitOfWork.CommitAsync();
        }

        public async Task DeleteRangeAsync(IEnumerable<Applicant> entityList)
        {
            _unitOfWork.Applicant.RemoveRange(entityList);
            await _unitOfWork.CommitAsync();
        }

        public async Task<IEnumerable<Applicant>> GetAllAsync()
        {
            return await _unitOfWork.Applicant.GetAllAsync();
        }

        public async Task<Applicant> GetByIdAsync(int id)
        {
            return await _unitOfWork.Applicant.GetByIdAsync(id);
        }

        public async Task UpdateAsync(Applicant entityToBeUpdated, Applicant entity)
        {
            entityToBeUpdated.Name = entity.Name;
            entityToBeUpdated.FamilyName = entity.FamilyName;
            entityToBeUpdated.EMailAddress = entity.EMailAddress;
            entityToBeUpdated.Address = entity.Address;
            entityToBeUpdated.CountryOfOrigin = entity.CountryOfOrigin;
            entityToBeUpdated.Age = entity.Age;
            entityToBeUpdated.Hired = entity.Hired;
            await _unitOfWork.CommitAsync();
        }

        #endregion


        #region CRUD operations without Async and await commands

        public Applicant Create(Applicant newEntity)
        {
            _unitOfWork.Applicant.Add(newEntity);
            return newEntity;
        }

        public IEnumerable<Applicant> CreateRange(IEnumerable<Applicant> entityList)
        {
            _unitOfWork.Applicant.AddRange(entityList);
            return entityList;
        }

        public int Delete(Applicant entity)
        {
            _unitOfWork.Applicant.Remove(entity);
            return _unitOfWork.Commit();
        }

        public int DeleteRange(IEnumerable<Applicant> entityList)
        {
            _unitOfWork.Applicant.RemoveRange(entityList);
            return _unitOfWork.Commit();
        }

        public IEnumerable<Applicant> GetAll()
        {
            return _unitOfWork.Applicant.GetAll();
        }

        public Applicant GetById(int id)
        {
            return _unitOfWork.Applicant.GetById(id);
        }

        public int Update(Applicant entityToBeUpdated, Applicant entity)
        {
            entityToBeUpdated.Name = entity.Name;
            entityToBeUpdated.FamilyName = entity.FamilyName;
            entityToBeUpdated.EMailAddress = entity.EMailAddress;
            entityToBeUpdated.Address = entity.Address;
            entityToBeUpdated.CountryOfOrigin = entity.CountryOfOrigin;
            entityToBeUpdated.Age = entity.Age;
            entityToBeUpdated.Hired = entity.Hired;
            return _unitOfWork.Commit();
        }

        #endregion


    }
}




