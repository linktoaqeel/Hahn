﻿using Hahn.ApplicatonProcess.December2020.Data.DAL;
using Hahn.ApplicatonProcess.December2020.Domain.IServices;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.ApplicatonProcess.December2020.Domain.Services
{
  public  class BaseService //<T>:BaseRepository<T>,IService<T>    where T : class
    {
        //public BaseService(IDbFactory dbFactory): base(dbFactory)
        //{
        //}
    }
}
