﻿using Hahn.ApplicatonProcess.December2020.Data.DAL;
using Hahn.ApplicatonProcess.December2020.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.IServices
{
    public interface IService<TEntity> where TEntity : class
    {

        #region Async CRUD operations 

        Task<TEntity> CreateAsync(TEntity newEntity);
        Task<IEnumerable<TEntity>> CreateRangeAsync(IEnumerable<TEntity> entityList);
        Task DeleteAsync(TEntity entity);
        Task DeleteRangeAsync(IEnumerable<TEntity> entityList);
        Task<IEnumerable<TEntity>> GetAllAsync();
        Task<TEntity> GetByIdAsync(int id);
        Task UpdateAsync(TEntity entityToBeUpdated, TEntity entity);

        #endregion


        #region CRUD operations without Async and await commands

        TEntity Create(TEntity newEntity);
        IEnumerable<TEntity> CreateRange(IEnumerable<TEntity> entityList);
        int Delete(TEntity entity);
        int DeleteRange(IEnumerable<TEntity> entityList);
        TEntity GetById(int id);
        IEnumerable<TEntity> GetAll();
        int Update(TEntity entityToBeUpdated, TEntity entity);

        #endregion

    }
}

